package com.rest.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
