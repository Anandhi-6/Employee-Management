package com.rest.api.serviceLayer;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.api.Employee;
import com.rest.api.repository.EmpRepository;

@Service
public class EmpServiceImplement implements EmployeeService{
	
	@Autowired
	private EmpRepository repo;
	
    public Employee addEmployee(Employee employee) {
    	return repo.save(employee);
    }
	
	public List<Employee> fetchEmployees(){
		List<Employee> employee = repo.findAll();
		return employee;
	}
	
	public Employee fetchEmployeeById(int id) {
		Optional<Employee> employee = repo.findById(id);
		if(employee.isPresent()) {
			return employee.get();
		}
		return null;
	}
	
	public Employee updateEmployee(int id, Employee employee) {
		Optional<Employee> employee1 = repo.findById(id);
		if(employee1.isPresent()) {
			Employee emp = employee1.get();
			if(Objects.nonNull(employee.getName()) && !"".equalsIgnoreCase(employee.getName())){
				emp.setName(employee.getName());
			}
			if(Objects.nonNull(employee.getEmail()) && !"".equalsIgnoreCase(employee.getEmail())){
				emp.setEmail(employee.getEmail());
			}
			if(Objects.nonNull(employee.getPhone_number()) && employee.getPhone_number() !=0){
				emp.setPhone_number(employee.getPhone_number());;
			}
			if(Objects.nonNull(employee.getDept()) && !"".equalsIgnoreCase(employee.getDept())){
				emp.setDept(employee.getDept());
			}
			if(Objects.nonNull(employee.getSkills()) && !"".equalsIgnoreCase(employee.getSkills())){
				emp.setSkills(employee.getSkills());
			}
			return repo.save(emp);
		}
		return null;
	}
	
	public String deleteEmployee(int id) {
		Optional<Employee> employee = repo.findById(id);
		if(employee.isPresent()) {
			repo.deleteById(id);
			return "Data deleted Successfully";
		}
		return "No such data in database";
	}

}
