package com.rest.api.serviceLayer;

import java.util.List;

import com.rest.api.Employee;

public interface EmployeeService {
	
	Employee addEmployee(Employee employee);
	
	List<Employee> fetchEmployees();
	
	Employee fetchEmployeeById(int id);
	
	Employee updateEmployee(int id, Employee employee);
	
	String deleteEmployee(int id);

}
