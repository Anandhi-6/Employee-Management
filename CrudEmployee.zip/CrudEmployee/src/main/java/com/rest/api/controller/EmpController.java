package com.rest.api.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rest.api.Employee;
//import com.rest.api.repository.EmpRepository;
import com.rest.api.serviceLayer.EmpServiceImplement;

@RestController


public class EmpController {
	
	@Autowired
	private EmpServiceImplement emp;
	
//	@Autowired
//	private EmpRepository repo;
	
//	@RequestMapping("home")
//	public String home() {
//		return "home.jsp";
//	}
	
//	@RequestMapping("employees")
//	public ModelAndView fetchEmployees() {
//		
//		List<Employee> employee = emp.fetchEmployees();
//		ModelAndView mv = new ModelAndView("home.jsp");
//		mv.addObject("emp", employee);
//		return mv;
//	}
	
	@PostMapping("/saveEmployee")
	public Employee saveEmpData(@RequestBody Employee employee) {
		return emp.addEmployee(employee);
	}
	
	@GetMapping("/getEmployee")
	public List<Employee> fetchEmpDetails(){
		return emp.fetchEmployees();
	}
	
	@GetMapping("/getEmployee/{id}")
	public Employee fetchEmpById(@PathVariable("id") int id) {
		return emp.fetchEmployeeById(id);
	}
	
	@PutMapping("/updateEmployee/{id}")
	public Employee updateEmpById(@PathVariable("id") int id, @RequestBody Employee employee) {
		return emp.updateEmployee(id, employee);
	}
	
	@DeleteMapping("/deleteEmployee/{id}")
	public String deleteEmpById(@PathVariable("id") int id) {
		return emp.deleteEmployee(id);
	}

}
